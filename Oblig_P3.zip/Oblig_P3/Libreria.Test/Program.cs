﻿using Libreria.LogicaNegocio.Entidades;
using Libreria.LogicaNegocio.Excepciones.Usuario;

namespace Libreria.Test
{
    internal class Program
    {
        static void Main(string[] args)
        {
             
        }
    }
}

