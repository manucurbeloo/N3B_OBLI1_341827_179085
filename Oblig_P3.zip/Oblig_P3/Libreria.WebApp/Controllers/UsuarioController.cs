﻿using Libreria.CasoDeUso_Compartida.InterfacesCU;
using Libreria.CasoDeUsoCompartida.DTOs.Usuarios;
using Libreria.CasoDeUsoCompartida.InterfacesCU;
using Libreria.LogicaNegocio.Excepciones.Usuario;
using Libreria.WebApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace Libreria.WebApp.Controllers
{
    public class UsuarioController : Controller
    {

        IGetAll<UsuarioListadoDto> _getAll;
        IAdd<UsuarioDto> _add;
        IRemove _remove;
        IGetByName<UsuarioListadoDto> _getByName;
        IGetById<UsuarioListadoDto> _getById;

        public UsuarioController(IGetAll<UsuarioListadoDto> getAll,
                                 IAdd<UsuarioDto> add,
                                 IRemove remove,
                                 IGetByName<UsuarioListadoDto> getByName,
                                 IGetById<UsuarioListadoDto> getById) 
        {
            _getAll = getAll;
            _add = add;
            _remove = remove;
            _getByName = getByName;
            _getById = getById;
        }


        public IActionResult Index()
        {
            return View(_getAll.Execute());
        }

        public IActionResult SerchName(string nombre)
        {
            return View("index",_getByName.Execute(nombre));
        }

        public IActionResult Create()
        {
            return View();
        }

        public IActionResult Details(int id)
        { 
            UsuarioListadoDto unU =  _getById.Execute(id);
            if (unU == null)
            {
                return RedirectToAction("index");
            }
            return View(unU);
        }

        [HttpPost]
        public IActionResult Create(VMUsuario usuario)
        {
            try
            {
                UsuarioDto unU = new UsuarioDto() 
                {
                    Id = usuario.Id,
                    Nombre = usuario.Nombre,
                    Email = usuario.Email,
                    Password = usuario.Password,
                    Rol = usuario.Rol,
                };                              
                _add.Execute(unU);
                return RedirectToAction("index");
            }
            catch (NombreException)
            {
                ViewBag.Message = "El nombre ingresado no es correcto";
            }
            catch (EmailException)
            {
                ViewBag.Message = "El email ingresado no es correcto";
            }
            catch (IdException)
            {
                ViewBag.Message = "El id ingresado no es correcto";
            }
            catch (Exception)
            {
                ViewBag.Message = "Hubo un error";
            }
            return View();

        }

        public IActionResult Delete(int id)
        {
            _remove.Execute(id);
            return RedirectToAction("index");
        }

    }
}
