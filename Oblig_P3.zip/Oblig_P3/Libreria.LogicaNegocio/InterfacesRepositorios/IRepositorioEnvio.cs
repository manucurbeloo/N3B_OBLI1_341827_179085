﻿

namespace Libreria.LogicaAccesoDatos.Lista
{
    public class IRepositorioAgencia
    {
    }
}
