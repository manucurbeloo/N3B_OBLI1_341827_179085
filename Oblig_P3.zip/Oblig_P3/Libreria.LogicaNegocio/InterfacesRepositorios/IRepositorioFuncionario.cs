﻿using Libreria.LogicaNegocio.Entidades;

namespace Libreria.LogicaAccesoDatos.Lista
{
    public interface IRepositorioAgencia
    {
    }
}
