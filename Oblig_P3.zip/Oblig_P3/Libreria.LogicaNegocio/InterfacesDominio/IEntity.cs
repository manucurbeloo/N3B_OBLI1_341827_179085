﻿
namespace Libreria.LogicaNegocio.IntefacesDominio
{
    internal interface IEntity
    {
        int Id {  get; set; }
    }
}
