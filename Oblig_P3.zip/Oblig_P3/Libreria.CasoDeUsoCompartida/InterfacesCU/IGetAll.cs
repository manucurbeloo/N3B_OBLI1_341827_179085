﻿
namespace Libreria.CasoDeUsoCompartida.InterfacesCU
{
    public interface IGetAll <T>
    {
        IEnumerable<T> Execute();
    }
}

