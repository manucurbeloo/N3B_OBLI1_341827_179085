﻿

namespace Libreria.CasoDeUso_Compartida.InterfacesCU
{
    public interface IAdd <T>
    {
        void Execute(T obj);
    }
}
