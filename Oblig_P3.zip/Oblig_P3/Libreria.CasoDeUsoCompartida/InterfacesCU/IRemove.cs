﻿
namespace Libreria.CasoDeUsoCompartida.InterfacesCU
{
    public interface IRemove
    {
        void Execute(int id);
    }
}
