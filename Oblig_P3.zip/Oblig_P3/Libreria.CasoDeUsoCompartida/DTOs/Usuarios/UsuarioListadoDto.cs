﻿

namespace Libreria.CasoDeUsoCompartida.DTOs.Usuarios
{
    public class UsuarioListadoDto
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Email { get; set; }
    }
}
