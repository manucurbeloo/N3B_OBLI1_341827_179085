﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libreria.CasoDeUso_Compartida.DTOs.Envio
{
    internal class EnvioDto
    {
    }
}
