﻿using Libreria.CasoDeUso_Compartida.InterfacesCU;
using Libreria.CasoDeUsoCompartida.DTOs.Usuarios;
using Libreria.LogicaNegocio.Entidades;
using Libreria.LogicaNegocio.InterfacesRepositorios;

namespace Libreria.LogicaAplicacion.CasoUso.Usuarios
{
    public class GetByName: IGetByName<UsuarioListadoDto>
    {
        private IRepositorioUsuario _repo;

        public GetByName(IRepositorioUsuario repo)
        {
            _repo = repo;
        }

        public IEnumerable<UsuarioListadoDto> Execute(string valor)
        {

            IEnumerable<Usuario> usuarios = _repo.GetByName(valor);
            List<UsuarioListadoDto> usuariosDto = new List<UsuarioListadoDto>();

            foreach (var item in usuarios)
            {
                usuariosDto.Add(new UsuarioListadoDto()
                {
                    Id = item.Id,
                    Nombre = item.Nombre,
                    Email = item.Email
                }
                );
            }

            return usuariosDto;
        }
    }
}
