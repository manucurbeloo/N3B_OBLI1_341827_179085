﻿
using Libreria.CasoDeUsoCompartida.DTOs.Usuarios;
using Libreria.CasoDeUsoCompartida.InterfacesCU;
using Libreria.LogicaNegocio.Entidades;
using Libreria.LogicaNegocio.InterfacesRepositorios;

namespace Libreria.LogicaAplicacion.CasoUso.Usuarios
{
    public class GetAllUsuario: IGetAll<UsuarioListadoDto>
    {
        private IRepositorioUsuario _repo;

        public GetAllUsuario(IRepositorioUsuario repo)
        {
            _repo = repo;
        }

        public IEnumerable<UsuarioListadoDto> Execute()
        {
            IEnumerable<Usuario> usuarios = _repo.GetAll();
            List<UsuarioListadoDto> usuariosDto = new List<UsuarioListadoDto>();

            foreach (var item in usuarios)
            {
                usuariosDto.Add(new UsuarioListadoDto()
                {
                    Id = item.Id,
                    Nombre = item.Nombre,
                    Email = item.Email
                }
                );
            }

            return usuariosDto;
        }
    }
}
